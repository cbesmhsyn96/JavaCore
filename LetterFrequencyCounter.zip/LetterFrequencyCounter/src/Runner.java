import display.DisplayCounts;

public class Runner extends DisplayCounts {

    public static void main(String[] args) {
        do {
            displayLetterCounts(letterCounter());
            System.out.println();
        }while (true);
    }

}