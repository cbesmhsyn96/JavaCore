package vars;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Defines {
    protected static String str;
    protected static Scanner scanner = new Scanner(System.in);
    protected static Map<Character,Integer> chrs = new LinkedHashMap<>();

}
